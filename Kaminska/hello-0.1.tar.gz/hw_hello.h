/** @file hw_hello.h
  * Plik nag��wkowy funkcji wypisuj�cych powitania
  * $Id$
  */

#ifndef HW_HELLO_H
#define HW_HELLO_H

int hello (void);

#endif
